problems:
1. sensiscript is running. it could run before
possibilities: file etension is missing (?)
there is some obvious problem in the ocde

what you just did:
in scratch folder, replaced sensitivity wrapper with old one that calls IBM 1.7 an dput IBM 1.7 back in. if it is a problem with the R code, this should run ok
did not run ok

are extensions ok?

problems:
1. you didn't call the code/set the directory correctly

pardraws.csv was removed and the code required this. this is in the output folder
putting this back in did not fix things